package net.codexdev.flutter_alarm_clock

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
